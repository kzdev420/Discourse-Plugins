class ::Archetype
  def self.chat
    'chat'
  end
end
