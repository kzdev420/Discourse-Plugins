class ::Babble::UserSerializer < BasicUserSerializer
  attributes :name, :last_posted_at
end
