This plugin is based on Official Discourse Advertising Plugin (https://github.com/discourse/discourse-adplugin), with some custom additions (AdTech tags support) and minor modifications.
 
It is **not meant for public use**.